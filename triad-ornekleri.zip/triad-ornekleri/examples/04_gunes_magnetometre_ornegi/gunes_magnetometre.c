/*
 * 04 - GERCEKCI ORNEK: GUNES SENSORU + MAGNETOMETRE ILE TRIAD
 * ==========================================================
 * Bu, depodaki EN GERCEKCI ornektir: gercek bir CubeSat/uydu ADCS
 * (Attitude Determination and Control System) yazilimindaki TRIAD
 * kullanimini uctan uca simule eder.
 *
 * IKI SENSOR KULLANILIR:
 *
 *   1) GUNES SENSORU (Sun Sensor)
 *      - Govde cercevesinde Gunes'in yonunu olcer.
 *      - Referans cercevesindeki (ECI/orbit) Gunes yonu, uydunun
 *        efemeris/zaman bilgisinden HESAPLANIR (bu ornekte
 *        basitlestirilmis sabit bir deger kullanilmistir).
 *      - GENELDE MAGNETOMETREDEN DAHA HASSASTIR (~0.1-0.5 derece
 *        hata payi), bu yuzden TRIAD'da BIRINCIL vektor (r1,b1)
 *        olarak secilir.
 *
 *   2) MAGNETOMETRE (Magnetometer)
 *      - Govde cercevesinde Dunya'nin manyetik alan yonunu olcer.
 *      - Referans cercevesindeki manyetik alan, IGRF (International
 *        Geomagnetic Reference Field) modelinden veya basit bir
 *        dipol modelinden hesaplanir (bu ornekte sabit deger).
 *      - Gunes sensorune gore DAHA GURULTULU olcum yapar (~1-2
 *        derece), bu yuzden TRIAD'da IKINCIL vektor (r2,b2) olarak
 *        secilir.
 *      - AVANTAJI: Gunes sensorunun aksine, uydu Dunya'nin
 *        golgesindeyken (eclipse) de calisir! Bu yuzden pratikte
 *        her iki sensor birlikte, ONCELIKLENDIRME ile kullanilir.
 *
 * NOT: dB/dt (magnetometre turevi) ile B-DOT KONTROL algoritmasi
 * (diger deponun 08 numarali ornegi) DETUMBLING (donme sonumleme)
 * icin kullanilirken, BU ornekteki TRIAD algoritmasi YONELIM
 * BELIRLEME (attitude determination) icindir. Ikisi birlikte tipik
 * bir ADCS pipeline'ini olusturur:
 *
 *      [Detumbling: B-dot]  ->  [Belirleme: TRIAD]  ->  [Ince kontrol: PD/kuaterniyon]
 */

#include <stdio.h>
#include <math.h>

typedef struct { double x, y, z; } Vec3;
typedef struct { double m[3][3]; } Mat3;

static Vec3 vnorm(Vec3 v) {
    double n = sqrt(v.x*v.x + v.y*v.y + v.z*v.z);
    Vec3 r = {v.x/n, v.y/n, v.z/n};
    return r;
}
static Vec3 vcross(Vec3 a, Vec3 b) {
    Vec3 r = { a.y*b.z-a.z*b.y, a.z*b.x-a.x*b.z, a.x*b.y-a.y*b.x };
    return r;
}
static Mat3 mat_from_cols(Vec3 c1, Vec3 c2, Vec3 c3) {
    Mat3 M;
    M.m[0][0]=c1.x; M.m[0][1]=c2.x; M.m[0][2]=c3.x;
    M.m[1][0]=c1.y; M.m[1][1]=c2.y; M.m[1][2]=c3.y;
    M.m[2][0]=c1.z; M.m[2][1]=c2.z; M.m[2][2]=c3.z;
    return M;
}
static Mat3 mat_mult_T(Mat3 A, Mat3 B) {
    Mat3 R;
    for (int i=0;i<3;i++) for (int j=0;j<3;j++) {
        double s=0; for (int k=0;k<3;k++) s += A.m[i][k]*B.m[j][k];
        R.m[i][j]=s;
    }
    return R;
}

/* ---------------------- ADIM 1: SENSOR OKUMALARI (SIMULE) ---------------------- */

/**
 * Gercek donanimda bu fonksiyon SPI/I2C uzerinden gunes sensorunden
 * (ornegin bir dizi fotodiyottan aci/akim degerleri okuyup birim
 * vektore cevirir) veri okur. Burada sabit, orneklenmis bir deger
 * dondurulmustur.
 */
static Vec3 gunes_sensoru_oku_govde(void)
{
    /* Govde cercevesinde olculen Gunes birim vektoru (ornek/simule) */
    return vnorm((Vec3){ 0.15, 0.85, 0.45 });
}

/**
 * Gercek donanimda 3 eksenli magnetometreden (I2C/SPI) ham veri
 * okunup kalibrasyon (bias/scale/soft-iron duzeltmesi) uygulanir.
 */
static Vec3 magnetometre_oku_govde(void)
{
    /* Govde cercevesinde olculen manyetik alan birim vektoru (ornek) */
    return vnorm((Vec3){ 0.62, -0.55, 0.35 });
}

/**
 * Referans cercevesindeki (ECI) Gunes yonu. Gercek sistemde bu,
 * yorunge zamanindan (epoch) SPICE/efemeris hesabi ile bulunur.
 */
static Vec3 gunes_referans_vektoru(void)
{
    return vnorm((Vec3){ 0.20, 0.10, 0.97 });
}

/**
 * Referans cercevesindeki (ECI) manyetik alan yonu. Gercek sistemde
 * IGRF modeli + uydunun konumundan (TLE/orbit propagator) hesaplanir.
 */
static Vec3 magnetik_referans_vektoru(void)
{
    return vnorm((Vec3){ 0.60, 0.70, -0.38 });
}

/* ---------------------- ADIM 2: TRIAD ---------------------- */

static Mat3 triad(Vec3 r1, Vec3 r2, Vec3 b1, Vec3 b2)
{
    Vec3 t1r = vnorm(r1);
    Vec3 t2r = vnorm(vcross(r1, r2));
    Vec3 t3r = vcross(t1r, t2r);

    Vec3 t1b = vnorm(b1);
    Vec3 t2b = vnorm(vcross(b1, b2));
    Vec3 t3b = vcross(t1b, t2b);

    Mat3 Mr = mat_from_cols(t1r, t2r, t3r);
    Mat3 Mb = mat_from_cols(t1b, t2b, t3b);

    return mat_mult_T(Mb, Mr);
}

/* ---------------------- ADIM 3: ONCELIKLENDIRME (ECLIPSE DURUMU) ---------------------- */

/**
 * eclipse_kontrolu()
 * ------------------------------------------------------
 * Uydu Dunya golgesindeyken (eclipse) gunes sensoru gecersiz veri
 * (veya sifir/cok dusuk isik siddeti) doner. Bu durumda TRIAD icin
 * SADECE magnetometre + (varsa) jiroskop turetilmis ikinci bir
 * vektor kullanilmalidir; ya da attitude propagasyonuna (son bilinen
 * yonelim + jiroskop entegrasyonu) gecilmelidir.
 *
 * Bu fonksiyon, basit bir esik (threshold) kontrolu ile eclipse
 * durumunu simule eder.
 */
static int eclipse_mi(double gunes_sensoru_isik_siddeti)
{
    const double ESIK = 0.05; /* normalize edilmis isik siddeti esigi */
    return gunes_sensoru_isik_siddeti < ESIK;
}

/* ---------------------- ANA PROGRAM ---------------------- */

int main(void)
{
    printf("=== GUNES SENSORU + MAGNETOMETRE ILE TRIAD (GERCEKCI ORNEK) ===\n\n");

    double isik_siddeti = 0.78; /* ornek: gunes sensoru gecerli okuma yapiyor */

    if (eclipse_mi(isik_siddeti)) {
        printf("UYARI: Uydu eclipse'te (Dunya golgesinde), gunes sensoru guvenilmez!\n");
        printf("       Bu durumda TRIAD yerine son bilinen yonelim + jiroskop\n");
        printf("       propagasyonu kullanilmalidir.\n");
        return 0;
    }

    /* 1) Sensor okumalari (govde cercevesi) */
    Vec3 b_gunes = gunes_sensoru_oku_govde();
    Vec3 b_mag   = magnetometre_oku_govde();

    /* 2) Referans vektorler (efemeris/IGRF) */
    Vec3 r_gunes = gunes_referans_vektoru();
    Vec3 r_mag   = magnetik_referans_vektoru();

    printf("Govde cercevesi (olculen):\n");
    printf("  Gunes vektoru : (%.4f, %.4f, %.4f)\n", b_gunes.x, b_gunes.y, b_gunes.z);
    printf("  Manyetik alan : (%.4f, %.4f, %.4f)\n\n", b_mag.x, b_mag.y, b_mag.z);

    printf("Referans cercevesi (efemeris/IGRF):\n");
    printf("  Gunes vektoru : (%.4f, %.4f, %.4f)\n", r_gunes.x, r_gunes.y, r_gunes.z);
    printf("  Manyetik alan : (%.4f, %.4f, %.4f)\n\n", r_mag.x, r_mag.y, r_mag.z);

    /* 3) TRIAD: Gunes vektoru BIRINCIL (daha guvenilir), manyetik IKINCIL */
    Mat3 A = triad(r_gunes, r_mag, b_gunes, b_mag);

    printf("Hesaplanan yonelim DCM'i (A):\n");
    for (int i = 0; i < 3; i++)
        printf("  [ %8.5f  %8.5f  %8.5f ]\n", A.m[i][0], A.m[i][1], A.m[i][2]);

    /* 4) Dogrulama: A ile referans gunes vektorunu dondurunce olculen
     *    govde gunes vektorune (yaklasik) esit olmali */
    Vec3 kontrol = {
        A.m[0][0]*r_gunes.x + A.m[0][1]*r_gunes.y + A.m[0][2]*r_gunes.z,
        A.m[1][0]*r_gunes.x + A.m[1][1]*r_gunes.y + A.m[1][2]*r_gunes.z,
        A.m[2][0]*r_gunes.x + A.m[2][1]*r_gunes.y + A.m[2][2]*r_gunes.z
    };
    printf("\nDogrulama (A * r_gunes): (%.4f, %.4f, %.4f)\n", kontrol.x, kontrol.y, kontrol.z);
    printf("Olculen b_gunes ile karsilastirin  : (%.4f, %.4f, %.4f)\n", b_gunes.x, b_gunes.y, b_gunes.z);

    printf("\nBu DCM artik kuaterniyona cevrilip (Ornek 03) bir PD kontrolcuye\n");
    printf("hedef yonelimle karsilastirmak icin verilebilir.\n");

    return 0;
}

/*
 * DERLEME:
 *    gcc gunes_magnetometre.c -o gercekci_ornek -lm
 *    ./gercekci_ornek
 *
 * GERCEK DONANIMA TASIRKEN:
 *   - gunes_sensoru_oku_govde() ve magnetometre_oku_govde() icine
 *     gercek I2C/SPI sensor okuma + kalibrasyon kodu yazin.
 *   - gunes_referans_vektoru() ve magnetik_referans_vektoru()
 *     fonksiyonlarini, uydunun anlik zamanina/konumuna gore efemeris
 *     ve IGRF hesaplarina baglayin (SPICE, pyIGRF, vb. kutuphaneler
 *     genelde yer istasyonu/OBC tarafinda calisir, sonuclar uploaded
 *     lookup-tablo olarak uyduya gonderilebilir).
 *   - eclipse_mi() esigini gercek sensorunuzun veri sayfasina gore
 *     kalibre edin.
 */
