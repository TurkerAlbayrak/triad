"""
02 - TRIAD Algoritmasi - Python/NumPy Dogrulama Scripti
==========================================================
Bu script, C implementasyonunu (Ornek 01) hizlica dogrulamak,
farkli senaryolari denemek ve sonucu bilinen kutuphanelerle
(scipy.spatial.transform) karsilastirmak icin yazilmistir.

Calistirmak icin:
    pip install numpy scipy
    python triad_verify.py
"""

import numpy as np


def normalize(v):
    """Bir vektoru birim vektore cevirir."""
    return v / np.linalg.norm(v)


def triad(r1, r2, b1, b2):
    """
    TRIAD algoritmasi.

    Parametreler
    ----------
    r1, r2 : (3,) ndarray
        Referans cercevesindeki birincil ve ikincil vektorler.
    b1, b2 : (3,) ndarray
        Govde (body) cercevesinde OLCULEN birincil ve ikincil vektorler.

    Donus
    -----
    A : (3,3) ndarray
        Referans cerceveden govde cercevesine DCM.
        v_body = A @ v_referans
    """
    r1, r2, b1, b2 = map(np.asarray, (r1, r2, b1, b2))

    # Referans ucgen (triad) tabani
    t1r = normalize(r1)
    t2r = normalize(np.cross(r1, r2))
    t3r = np.cross(t1r, t2r)

    # Govde ucgen (triad) tabani
    t1b = normalize(b1)
    t2b = normalize(np.cross(b1, b2))
    t3b = np.cross(t1b, t2b)

    Mr = np.column_stack([t1r, t2r, t3r])
    Mb = np.column_stack([t1b, t2b, t3b])

    # A = Mb * Mr^T  (Mr ortonormal oldugu icin Mr^-1 = Mr^T)
    A = Mb @ Mr.T
    return A


def attitude_hatasi_derece(A_gercek, A_tahmin):
    """
    Iki DCM arasindaki aci farkini (derece cinsinden) hesaplar.
    Rodrigues / iz (trace) formulu:
        cos(theta) = (trace(A_gercek^T * A_tahmin) - 1) / 2
    """
    A_fark = A_gercek.T @ A_tahmin
    cos_theta = (np.trace(A_fark) - 1.0) / 2.0
    cos_theta = np.clip(cos_theta, -1.0, 1.0)  # sayisal guvenlik
    return np.degrees(np.arccos(cos_theta))


def senaryo_calistir(isim, r1, r2, b1, b2, A_gercek=None):
    print(f"\n--- {isim} ---")
    A = triad(r1, r2, b1, b2)
    print("Hesaplanan DCM:\n", np.round(A, 5))

    # Ortogonallik kontrolu: A * A^T = I olmali
    ortho_hata = np.max(np.abs(A @ A.T - np.eye(3)))
    print(f"Ortogonallik hatasi (max |A A^T - I|): {ortho_hata:.2e}")

    # Determinant +1 olmali (gercek rotasyon, yansima degil)
    print(f"det(A) = {np.linalg.det(A):.6f}  (1.0 olmali)")

    if A_gercek is not None:
        hata_derece = attitude_hatasi_derece(A_gercek, A)
        print(f"Gercek DCM'e gore yonelim hatasi: {hata_derece:.4f} derece")


if __name__ == "__main__":
    print("=== TRIAD ALGORITMASI DOGRULAMA (Python/NumPy) ===")

    # ---- Senaryo 1: Z ekseni etrafinda 90 derece rotasyon (gurultusuz) ----
    r1 = np.array([1.0, 0.0, 0.0])
    r2 = np.array([0.0, 1.0, 0.0])

    theta = np.radians(90)
    Rz = np.array([
        [ np.cos(theta), np.sin(theta), 0],
        [-np.sin(theta), np.cos(theta), 0],
        [0, 0, 1]
    ])
    b1 = Rz @ r1
    b2 = Rz @ r2
    senaryo_calistir("Senaryo 1: Z ekseninde 90 derece (gurultusuz)", r1, r2, b1, b2, A_gercek=Rz)

    # ---- Senaryo 2: Rastgele 3 eksenli rotasyon + kucuk sensor gurultusu ----
    np.random.seed(42)
    aci = np.radians([30, -20, 55])  # roll, pitch, yaw benzeri
    cx, cy, cz = np.cos(aci)
    sx, sy, sz = np.sin(aci)
    Rx = np.array([[1,0,0],[0,cx,-sx],[0,sx,cx]])
    Ry = np.array([[cy,0,sy],[0,1,0],[-sy,0,cy]])
    Rz2 = np.array([[cz,-sz,0],[sz,cz,0],[0,0,1]])
    A_gercek = Rz2 @ Ry @ Rx

    r1 = normalize(np.array([0.2, 0.1, 0.97]))   # ornek: Gunes vektoru
    r2 = normalize(np.array([0.6, 0.7, -0.38]))  # ornek: Manyetik alan vektoru

    gurultu_seviyesi = 0.01  # ~ %1 vektor gurultusu
    b1 = normalize(A_gercek @ r1 + gurultu_seviyesi * np.random.randn(3))
    b2 = normalize(A_gercek @ r2 + gurultu_seviyesi * np.random.randn(3))

    senaryo_calistir("Senaryo 2: Rastgele rotasyon + %1 sensor gurultusu", r1, r2, b1, b2, A_gercek=A_gercek)

    # ---- Senaryo 3: r1/r2 sirasini degistirme etkisi ----
    # TRIAD ASIMETRIKTIR: hangi vektorun "birincil" (r1,b1) secildigi sonucu etkiler!
    A_v1 = triad(r1, r2, b1, b2)          # r1 birincil
    A_v2 = triad(r2, r1, b2, b1)          # r2 birincil (roller degisti)
    fark_derece = attitude_hatasi_derece(A_v1, A_v2)
    print(f"\n--- Senaryo 3: Birincil vektor secimi etkisi ---")
    print(f"r1-birincil ile r2-birincil DCM'leri arasi fark: {fark_derece:.4f} derece")
    print("(Gurultu varsa bu fark sifirdan buyuk olur; en dogru sensoru")
    print(" HER ZAMAN birincil (r1,b1) olarak secmek gerekir.)")
