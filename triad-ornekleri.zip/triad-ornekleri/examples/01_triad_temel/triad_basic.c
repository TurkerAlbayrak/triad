/*
 * 01 - TRIAD ALGORITMASI - TEMEL IMPLEMENTASYON
 * ==========================================================
 * TRIAD, iki farkli vektor olcumunden (birisi "birincil/guvenilir",
 * digeri "ikincil") bir cismin yonelimini (attitude) veren 3x3'luk
 * Yon Kosinus Matrisini (DCM - Direction Cosine Matrix) hesaplayan
 * klasik, deterministik bir yontemdir.
 *
 * FIKIR:
 *   Ayni iki fiziksel vektoru (ornegin Gunes yonu ve Dunya'nin
 *   manyetik alan yonu) IKI FARKLI koordinat cercevesinde biliyoruz:
 *
 *     - REFERANS cercevesi (r): Bu vektorlerin bilinen/hesaplanan
 *       degerleri (ornegin gunes efemerisinden, IGRF manyetik alan
 *       modelinden).
 *     - GOVDE (body) cercevesi (b): Bu vektorlerin uydu uzerindeki
 *       sensorlerle (gunes sensoru, magnetometre) OLCULEN degerleri.
 *
 *   Eger govde cercevesindeki bu iki vektoru referans cercevesindeki
 *   karsiliklarina "dondurecek" R rotasyon matrisini bulursak, bu R
 *   matrisi uydunun o anki YONELIMINI (attitude) verir.
 *
 * NEDEN TEK BIR VEKTOR YETMEZ?
 *   Tek bir vektor eslesmesi (b1 -> r1), rotasyonu o vektor
 *   ekseni etrafinda dondurme (roll) serbestligini BELIRSIZ
 *   birakir - sonsuz sayida cozum vardir. Bu yuzden BIRBIRINDEN
 *   BAGIMSIZ (paralel olmayan) EN AZ IKI vektor olcumu gerekir.
 */

#include <stdio.h>
#include <math.h>

typedef struct { double x, y, z; } Vec3;
typedef struct { double m[3][3]; } Mat3;

/* ---------------------- VEKTOR YARDIMCI FONKSIYONLARI ---------------------- */

static Vec3 vec_normalize(Vec3 v)
{
    double n = sqrt(v.x*v.x + v.y*v.y + v.z*v.z);
    Vec3 r = { v.x/n, v.y/n, v.z/n };
    return r;
}

static Vec3 vec_cross(Vec3 a, Vec3 b)
{
    Vec3 r;
    r.x = a.y*b.z - a.z*b.y;
    r.y = a.z*b.x - a.x*b.z;
    r.z = a.x*b.y - a.y*b.x;
    return r;
}

static double vec_dot(Vec3 a, Vec3 b)
{
    return a.x*b.x + a.y*b.y + a.z*b.z;
}

/* M'nin sutunlari t1,t2,t3 vektorleri olacak sekilde 3x3 matris kurar */
static Mat3 mat_from_columns(Vec3 t1, Vec3 t2, Vec3 t3)
{
    Mat3 M;
    M.m[0][0]=t1.x; M.m[0][1]=t2.x; M.m[0][2]=t3.x;
    M.m[1][0]=t1.y; M.m[1][1]=t2.y; M.m[1][2]=t3.y;
    M.m[2][0]=t1.z; M.m[2][1]=t2.z; M.m[2][2]=t3.z;
    return M;
}

/* A * B^T (B'nin transpozu ile carpim) */
static Mat3 mat_mult_transpose(Mat3 A, Mat3 B)
{
    Mat3 R;
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            double toplam = 0.0;
            for (int k = 0; k < 3; k++) {
                toplam += A.m[i][k] * B.m[j][k]; // B^T[k][j] = B[j][k]
            }
            R.m[i][j] = toplam;
        }
    }
    return R;
}

static void mat_print(const char *isim, Mat3 M)
{
    printf("%s =\n", isim);
    for (int i = 0; i < 3; i++) {
        printf("  [ %8.5f  %8.5f  %8.5f ]\n", M.m[i][0], M.m[i][1], M.m[i][2]);
    }
}

/* ---------------------- TRIAD CEKIRDEK ALGORITMASI ---------------------- */

/**
 * triad_hesapla()
 * ------------------------------------------------------
 * @param r1 Birincil (guvenilir) vektorun REFERANS cercevesindeki hali
 * @param r2 Ikincil vektorun REFERANS cercevesindeki hali
 * @param b1 Birincil vektorun GOVDE (body) cercevesinde OLCULEN hali
 * @param b2 Ikincil vektorun GOVDE cercevesinde OLCULEN hali
 * @return   A: Referans cerceveden govde cercevesine donusum DCM'i
 *              (govde_vektoru = A * referans_vektoru)
 *
 * ONEMLI: r1/b1 cifti, r2/b2 ciftinden DAHA GUVENILIR olan olcum
 * olmalidir (ornegin gunes sensoru, magnetometreden genelde daha
 * dogrudur). TRIAD, birincil vektoru TAM KORUYARAK, ikincil vektoru
 * yalnizca "yon/dogrultu" (roll'u belirlemek) icin kullanir.
 */
static Mat3 triad_hesapla(Vec3 r1, Vec3 r2, Vec3 b1, Vec3 b2)
{
    /* --- Referans cercevesinde ortonormal ucgen (triad) taban --- */
    Vec3 t1r = vec_normalize(r1);
    Vec3 t2r = vec_normalize(vec_cross(r1, r2));
    Vec3 t3r = vec_cross(t1r, t2r); // zaten birim vektor (t1r, t2r dik ve birim)

    /* --- Govde cercevesinde ortonormal ucgen (triad) taban --- */
    Vec3 t1b = vec_normalize(b1);
    Vec3 t2b = vec_normalize(vec_cross(b1, b2));
    Vec3 t3b = vec_cross(t1b, t2b);

    /* --- Iki taban matrisini kur --- */
    Mat3 Mr = mat_from_columns(t1r, t2r, t3r); // referans-cercevesi taban matrisi
    Mat3 Mb = mat_from_columns(t1b, t2b, t3b); // govde-cercevesi taban matrisi

    /*
     * Herhangi bir referans-cercevesi vektoru v_r icin, govde
     * cercevesindeki karsiligi v_b = A * v_r olacak sekilde A'yi
     * ariyoruz. t1b = A*t1r, t2b = A*t2r, t3b = A*t3r oldugundan:
     *
     *      Mb = A * Mr   =>   A = Mb * Mr^{-1} = Mb * Mr^T
     *
     * (Mr ortonormal (rotasyon) matris oldugu icin Mr^{-1} = Mr^T)
     */
    Mat3 A = mat_mult_transpose(Mb, Mr);
    return A;
}

/* ---------------------- ORNEK KULLANIM ---------------------- */

int main(void)
{
    printf("=== TRIAD ALGORITMASI - TEMEL ORNEK ===\n\n");

    /* Referans cercevesindeki iki bilinen (birim) vektor */
    Vec3 r1 = { 1.0, 0.0, 0.0 };   /* ornek: Gunes yonu (referans cerceve) */
    Vec3 r2 = { 0.0, 1.0, 0.0 };   /* ornek: Manyetik alan yonu (referans) */

    /* Uydunun govdesinde OLCULEN (rotasyona ugramis) karsiliklari.
     * Burada r1/r2, Z ekseni etrafinda 90 derece dondurulmus gibi
     * simule edilmistir: X ekseni -> -Y, Y ekseni -> X */
    Vec3 b1 = { 0.0, -1.0, 0.0 };
    Vec3 b2 = { 1.0,  0.0, 0.0 };

    Mat3 A = triad_hesapla(r1, r2, b1, b2);

    mat_print("Hesaplanan DCM (A)", A);

    /* Dogrulama: A * r1 == b1 olmali */
    Vec3 test = {
        A.m[0][0]*r1.x + A.m[0][1]*r1.y + A.m[0][2]*r1.z,
        A.m[1][0]*r1.x + A.m[1][1]*r1.y + A.m[1][2]*r1.z,
        A.m[2][0]*r1.x + A.m[2][1]*r1.y + A.m[2][2]*r1.z
    };
    printf("\nDogrulama: A*r1 = (%.3f, %.3f, %.3f)  (beklenen b1 = (%.3f, %.3f, %.3f))\n",
           test.x, test.y, test.z, b1.x, b1.y, b1.z);

    return 0;
}

/*
 * DERLEME (test icin):
 *    gcc triad_basic.c -o triad_test -lm
 *    ./triad_test
 *
 * NOT: Bu dosyada b1,b2 elle "uydurulmus" ornek degerlerdir.
 * Gercek bir ADCS pipeline'inda bu vektorler gunes sensoru ve
 * magnetometre okumalarindan gelir (bkz. Ornek 04).
 */
