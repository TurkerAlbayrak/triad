"""
05 - TRIAD HATA VE GURULTU ANALIZI
==========================================================
Bu script, TRIAD algoritmasinin dogrulugunu etkileyen iki temel
faktoru sayisal olarak inceler:

  1) SENSOR GURULTUSU: Olcum vektorlerine eklenen rastgele hata,
     cikan DCM'de ne kadar yonelim hatasina (derece) donusuyor?

  2) VEKTORLER ARASI ACI: r1 ve r2 (Gunes ve manyetik alan
     vektorleri) birbirine ne kadar YAKIN (paralel), TRIAD o
     kadar KOTU sonuc verir. Bu, cross-product'in kucuk vektorler
     uretmesinden kaynaklanir (sayisal hassasiyet dusuklugu).

Sonuc: iyi bir TRIAD tasarimi (a) en dusuk gurultulu sensoru
birincil vektor secer, (b) iki referans vektorun mumkun oldugunca
ORTOGONALE YAKIN (90 dereceye yakin) olmasini saglayacak yorunge/
zamanlama secimi yapar.

Calistirmak icin:
    pip install numpy matplotlib
    python noise_analysis.py
"""

import numpy as np


def normalize(v):
    return v / np.linalg.norm(v)


def triad(r1, r2, b1, b2):
    t1r = normalize(r1)
    t2r = normalize(np.cross(r1, r2))
    t3r = np.cross(t1r, t2r)

    t1b = normalize(b1)
    t2b = normalize(np.cross(b1, b2))
    t3b = np.cross(t1b, t2b)

    Mr = np.column_stack([t1r, t2r, t3r])
    Mb = np.column_stack([t1b, t2b, t3b])
    return Mb @ Mr.T


def attitude_hatasi_derece(A_gercek, A_tahmin):
    A_fark = A_gercek.T @ A_tahmin
    cos_theta = np.clip((np.trace(A_fark) - 1.0) / 2.0, -1.0, 1.0)
    return np.degrees(np.arccos(cos_theta))


def rastgele_dcm(seed=None):
    rng = np.random.default_rng(seed)
    aci = rng.uniform(-np.pi, np.pi, size=3)
    cx, cy, cz = np.cos(aci); sx, sy, sz = np.sin(aci)
    Rx = np.array([[1,0,0],[0,cx,-sx],[0,sx,cx]])
    Ry = np.array([[cy,0,sy],[0,1,0],[-sy,0,cy]])
    Rz = np.array([[cz,-sz,0],[sz,cz,0],[0,0,1]])
    return Rz @ Ry @ Rx


def gurultu_ekle(v, sigma, rng):
    """Kucuk-aci yaklasimiyla vektore rastgele gurultu ekler ve normalize eder."""
    v_gurultulu = v + sigma * rng.standard_normal(3)
    return normalize(v_gurultulu)


def deney_1_gurultu_seviyesi_taramasi():
    print("\n=== DENEY 1: Sensor Gurultusu -> Yonelim Hatasi Iliskisi ===")
    print(f"{'Gurultu sigma':>15} | {'Ort. hata (derece)':>20} | {'Std sapma':>10}")
    print("-" * 52)

    A_gercek = rastgele_dcm(seed=1)
    r1 = normalize(np.array([0.2, 0.1, 0.97]))   # Gunes (referans)
    r2 = normalize(np.array([0.6, 0.7, -0.38]))  # Manyetik (referans)

    N_deneme = 500
    for sigma in [0.0, 0.001, 0.005, 0.01, 0.02, 0.05]:
        hatalar = []
        rng = np.random.default_rng(0)
        for _ in range(N_deneme):
            b1 = gurultu_ekle(A_gercek @ r1, sigma, rng)
            b2 = gurultu_ekle(A_gercek @ r2, sigma, rng)
            A_est = triad(r1, r2, b1, b2)
            hatalar.append(attitude_hatasi_derece(A_gercek, A_est))
        hatalar = np.array(hatalar)
        print(f"{sigma:>15.4f} | {hatalar.mean():>20.4f} | {hatalar.std():>10.4f}")

    print("\nYorum: Gurultu sigma'si buyudukce yonelim hatasi (derece) da")
    print("yaklasik dogrusal olarak artar. Bu yuzden magnetometre/gunes")
    print("sensoru kalibrasyonu TRIAD dogrulugunun temelidir.")


def deney_2_vektor_acisi_taramasi():
    print("\n\n=== DENEY 2: Referans Vektorler Arasi Aci -> Hata Hassasiyeti ===")
    print(f"{'r1-r2 acisi (derece)':>22} | {'Ort. hata (derece)':>20}")
    print("-" * 46)

    A_gercek = rastgele_dcm(seed=2)
    sigma = 0.01  # sabit %1 gurultu
    N_deneme = 500

    r1 = np.array([1.0, 0.0, 0.0])  # sabit "Gunes" referansi

    for aci_derece in [10, 30, 60, 90, 120, 150, 170]:
        aci_rad = np.radians(aci_derece)
        # r1'e aci_derece kadar acili, XY duzleminde bir r2 uret
        r2 = np.array([np.cos(aci_rad), np.sin(aci_rad), 0.0])

        hatalar = []
        rng = np.random.default_rng(1)
        for _ in range(N_deneme):
            b1 = gurultu_ekle(A_gercek @ r1, sigma, rng)
            b2 = gurultu_ekle(A_gercek @ r2, sigma, rng)
            A_est = triad(r1, r2, b1, b2)
            hatalar.append(attitude_hatasi_derece(A_gercek, A_est))
        hatalar = np.array(hatalar)
        print(f"{aci_derece:>22} | {hatalar.mean():>20.4f}")

    print("\nYorum: Vektorler birbirine paralele yaklastikca (0 veya 180")
    print("dereceye yakin acilar) yonelim hatasi HIZLA BUYUR. En iyi")
    print("performans ~90 derece (ortogonal) civarinda elde edilir.")
    print("Bu yuzden yorunge planlamasinda Gunes-Dunya manyetik alan")
    print("vektorlerinin acisi izlenmeli, cok kucuk oldugu anlarda")
    print("TRIAD ciktisina daha az guvenilmelidir (kovaryans agirlikli")
    print("QUEST/EKF gibi yontemler tercih edilebilir).")


if __name__ == "__main__":
    deney_1_gurultu_seviyesi_taramasi()
    deney_2_vektor_acisi_taramasi()
