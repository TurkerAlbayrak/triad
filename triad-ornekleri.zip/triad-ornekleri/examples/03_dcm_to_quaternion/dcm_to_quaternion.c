/*
 * 03 - TRIAD CIKTISI DCM'DEN KUATERNIYONA DONUSUM
 * ==========================================================
 * TRIAD algoritmasi cikisi olarak 3x3'luk bir DCM (Direction
 * Cosine Matrix) uretir. Ancak gercek bir ADCS (yonelim kontrol)
 * yazilimi genelde durumu KUATERNIYON (quaternion) olarak tasir,
 * cunku kuaterniyonlar:
 *
 *   - Gimbal lock (kutup kilitlenmesi) sorunu yasamaz (Euler
 *     acilarinin aksine),
 *   - Yalnizca 4 sayidan olustugu icin DCM'in 9 sayisina gore
 *     daha az bellek/islem gerektirir,
 *   - Kontrolcu (ornegin B-dot, PD kontrolcu) tasarimlarinda
 *     dogrudan kullanilabilir hata metrikleri saglar.
 *
 * Bu dosya, standart "Shepperd" yontemine benzer, sayisal olarak
 * kararli bir DCM -> kuaterniyon donusumu icerir (en buyuk
 * diyagonal elemana gore dallanma).
 *
 * Kuaterniyon gosterimi: q = [q0, q1, q2, q3] = [w, x, y, z]
 * (q0 = skaler/gercek kisim, q1..q3 = vektor/hayali kisim)
 */

#include <stdio.h>
#include <math.h>

typedef struct { double m[3][3]; } Mat3;
typedef struct { double w, x, y, z; } Quat;

/**
 * dcm_to_quat()
 * ------------------------------------------------------
 * DCM'i (A) kuaterniyona cevirir. Sayisal kararlilik icin,
 * dort olasi formulden (w^2, x^2, y^2, z^2 icin) en buyuk
 * paydaya sahip olani secer.
 */
static Quat dcm_to_quat(Mat3 A)
{
    double tr = A.m[0][0] + A.m[1][1] + A.m[2][2]; // iz (trace)
    Quat q;

    if (tr > 0.0) {
        double S = sqrt(tr + 1.0) * 2.0; // S = 4*q0
        q.w = 0.25 * S;
        q.x = (A.m[2][1] - A.m[1][2]) / S;
        q.y = (A.m[0][2] - A.m[2][0]) / S;
        q.z = (A.m[1][0] - A.m[0][1]) / S;
    } else if ((A.m[0][0] > A.m[1][1]) && (A.m[0][0] > A.m[2][2])) {
        double S = sqrt(1.0 + A.m[0][0] - A.m[1][1] - A.m[2][2]) * 2.0; // S = 4*q1
        q.w = (A.m[2][1] - A.m[1][2]) / S;
        q.x = 0.25 * S;
        q.y = (A.m[0][1] + A.m[1][0]) / S;
        q.z = (A.m[0][2] + A.m[2][0]) / S;
    } else if (A.m[1][1] > A.m[2][2]) {
        double S = sqrt(1.0 + A.m[1][1] - A.m[0][0] - A.m[2][2]) * 2.0; // S = 4*q2
        q.w = (A.m[0][2] - A.m[2][0]) / S;
        q.x = (A.m[0][1] + A.m[1][0]) / S;
        q.y = 0.25 * S;
        q.z = (A.m[1][2] + A.m[2][1]) / S;
    } else {
        double S = sqrt(1.0 + A.m[2][2] - A.m[0][0] - A.m[1][1]) * 2.0; // S = 4*q3
        q.w = (A.m[1][0] - A.m[0][1]) / S;
        q.x = (A.m[0][2] + A.m[2][0]) / S;
        q.y = (A.m[1][2] + A.m[2][1]) / S;
        q.z = 0.25 * S;
    }
    return q;
}

/* Kuaterniyonu normalize eder (sayisal hatalarin birikmesini onlemek icin) */
static Quat quat_normalize(Quat q)
{
    double n = sqrt(q.w*q.w + q.x*q.x + q.y*q.y + q.z*q.z);
    Quat r = { q.w/n, q.x/n, q.y/n, q.z/n };
    return r;
}

/* Kuaterniyondan DCM'e geri donusum (dogrulama icin) */
static Mat3 quat_to_dcm(Quat q)
{
    Mat3 A;
    double w=q.w, x=q.x, y=q.y, z=q.z;
    A.m[0][0] = 1 - 2*(y*y + z*z);
    A.m[0][1] = 2*(x*y - w*z);
    A.m[0][2] = 2*(x*z + w*y);
    A.m[1][0] = 2*(x*y + w*z);
    A.m[1][1] = 1 - 2*(x*x + z*z);
    A.m[1][2] = 2*(y*z - w*x);
    A.m[2][0] = 2*(x*z - w*y);
    A.m[2][1] = 2*(y*z + w*x);
    A.m[2][2] = 1 - 2*(x*x + y*y);
    return A;
}

int main(void)
{
    /* Ornek: Ornek 01'den gelen Z ekseninde 90 derecelik DCM */
    Mat3 A = {{
        { 0.0,  1.0, 0.0},
        {-1.0,  0.0, 0.0},
        { 0.0,  0.0, 1.0}
    }};

    printf("=== TRIAD DCM -> KUATERNIYON DONUSUMU ===\n\n");

    Quat q = dcm_to_quat(A);
    q = quat_normalize(q);

    printf("Kuaterniyon: q = [w=%.5f, x=%.5f, y=%.5f, z=%.5f]\n", q.w, q.x, q.y, q.z);

    double norm = sqrt(q.w*q.w + q.x*q.x + q.y*q.y + q.z*q.z);
    printf("Birim kontrolu |q| = %.6f  (1.0 olmali)\n\n", norm);

    /* Geri donusumle dogrula */
    Mat3 A_geri = quat_to_dcm(q);
    printf("Geri donusum ile DCM (dogrulama):\n");
    for (int i = 0; i < 3; i++)
        printf("  [ %8.5f  %8.5f  %8.5f ]\n", A_geri.m[i][0], A_geri.m[i][1], A_geri.m[i][2]);

    /* Kuaterniyondan Euler acilarina (aci hatasi/gorsellestirme icin, isteğe bagli) */
    double roll  = atan2(2*(q.w*q.x + q.y*q.z), 1 - 2*(q.x*q.x + q.y*q.y));
    double pitch = asin(fmax(-1.0, fmin(1.0, 2*(q.w*q.y - q.z*q.x))));
    double yaw   = atan2(2*(q.w*q.z + q.x*q.y), 1 - 2*(q.y*q.y + q.z*q.z));

    printf("\nEuler acilari (derece): roll=%.3f, pitch=%.3f, yaw=%.3f\n",
           roll*180.0/M_PI, pitch*180.0/M_PI, yaw*180.0/M_PI);

    return 0;
}

/*
 * DERLEME:
 *    gcc dcm_to_quaternion.c -o dcm_to_quat_test -lm
 *    ./dcm_to_quat_test
 *
 * Gercek bir ADCS pipeline'inda tipik akis:
 *    magnetometre + gunes sensoru olcumleri
 *      -> triad_hesapla() (Ornek 01)          -> DCM
 *      -> dcm_to_quat()   (bu dosya)           -> Kuaterniyon
 *      -> kuaterniyon hata hesaplama + PD kontrolcu -> magnetorquer/reaksiyon tekeri komutlari
 */
